package de.luh.hci.mi.vibrationpattern

import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import de.luh.hci.mi.vibrationpattern.ui.theme.VibrationPatternTheme

class MainActivity : ComponentActivity() {
    private lateinit var vibrator: Vibrator

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vibrator = getSystemService(Vibrator::class.java)
        setContent {
            View()
        }
    }

    @Preview(showBackground = true)
    @Composable
    fun View() {
        VibrationPatternTheme {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color.LightGray
            ) {
                Column {
                    Text(text = "Play vibration pattern")
                    Button(
                        onClick = { vibrator.vibrate(HEART) },
                    ) {
                        Text("Heartbeat")
                    }
                    Button(
                        onClick = { vibrator.cancel() },
                    ) {
                        Text("Stop")
                    }
                }
            }
        }
    }

    companion object {
        private val HEART = VibrationEffect.createWaveform(
            longArrayOf(
                0,
                65,
                297,
                44,
                552 // wait 0ms, vibrate 65 ms, pause 297 ms, vibrate 44 ms, pause 552 ms
            ), 1
        )
        private val SOS = VibrationEffect.createWaveform(
            longArrayOf(
                0, 100, 100, 100, 100, 100, 100,
                300, 100, 300, 100, 300, 100,
                100, 100, 100, 100, 100, 100,
                0, 1000
            ), 1
        )
        private val WALTZ = VibrationEffect.createWaveform(
            longArrayOf(
                0, 100, 200, 70, 230, 70, 230
            ), 1
        )
        private val vibes = arrayOf(HEART, SOS, WALTZ)
    }
}