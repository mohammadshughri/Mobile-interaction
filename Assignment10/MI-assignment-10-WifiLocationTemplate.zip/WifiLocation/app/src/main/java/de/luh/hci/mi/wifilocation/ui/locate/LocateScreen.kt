package de.luh.hci.mi.wifilocation.ui.locate

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

const val maxResults = 10

// Shows the locations that best match the current fingerprint.
@Composable
fun LocateScreen(
    navigateBack: () -> Unit,
    viewModel: LocateViewModel
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // todo: implement...
        Text("implement...", fontSize = 24.sp)
    }
}
