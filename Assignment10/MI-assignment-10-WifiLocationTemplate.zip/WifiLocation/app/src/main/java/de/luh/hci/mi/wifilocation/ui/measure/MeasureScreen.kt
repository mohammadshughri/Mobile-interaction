package de.luh.hci.mi.wifilocation.ui.measure

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.sp

// Limit the number of scan results to be shown.
const val maxResults = 7

// UI for showing WiFi fingerprints and for saving a fingerprint.
@Composable
fun MeasureScreen(
    navigateBack: () -> Unit, // navigate back to previous screen
    viewModel: MeasureViewModel // the view model of this screen
) {
    // needed for showing a popup message
    val snackbarHostState = remember {
        SnackbarHostState()
    }

    Scaffold(
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState)
        },
    ) { paddingValues ->

        // If message is not null, then show it to the user.
        // https://developer.android.com/topic/architecture/ui-layer/events#compose_3
        viewModel.message?.let { message ->
            LaunchedEffect(message) {
                snackbarHostState.showSnackbar(message)
                viewModel.messageShown()
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // todo: implement...
            Text("implement...", fontSize = 24.sp)

            if (viewModel.scanResults.isEmpty()) {
                Text("Scan running...", fontSize = 24.sp)
            } else {
                Text("${viewModel.scanResults.size} Scan Results", fontSize = 24.sp)
            }
        }
    }
}
