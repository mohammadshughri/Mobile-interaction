package de.luh.hci.mi.logisticregression;


public class LogisticRegression {
	
	public final static String basePath = "";
	

	
	/** Feature vector has dimension N (3D points are flattened, additional 1) */
	public final static int N = GestureClass.SAMPLE_POINTS_COUNT * 3 + 1;
	
	/** Number of templates to use for training. */
	public final static int TRAINING_COUNT =3;

	/** Learning rate. */
	double alpha = 0.91;

	/** The number of iterations used in training. */
	int TRAINING_ITERATIONS = 100;
	
	public void trainAndCrossValidate(GestureClass classA, GestureClass classB) {
		classA.gestureId = 0;
		classB.gestureId = 1;
		
		// generate training data
		// needs a matrix format for trainXs
		// - each row trainXs[i] contains one feature vector (N dimensional)
		// - trainYs[i] is the class (0 or 1) of this feature vector
		// - the pair trainXs[i], trainYs[i]) is one training example (associates feature vector and class)

		double[][] trainXs = new double[2 * TRAINING_COUNT][N]; // training examples for each of the two classes
		int[] trainYs = new int[2 * TRAINING_COUNT]; // the class (0 or 1) of each feature vector
		getTrainingData(classA, 0, TRAINING_COUNT, trainXs, trainYs, 0); // training examples for class 0
		getTrainingData(classB, 0, TRAINING_COUNT, trainXs, trainYs, TRAINING_COUNT); // training examples for class 1
		
		// do the training given the training examples
		
		double[] w = train(trainXs, trainYs);

		// see which ones it gets correct
		
		// these should all belong to class 0
		int correct = 0;
		System.out.println(classA.name + ":");
		for (int i = TRAINING_COUNT; i < classA.templates.size(); i++) {
			double[] xs = toXs(classA.templates.get(i));
			double h = h(xs, w);
			System.out.printf("%4.2f\n", h);
			if (h < 0.5) correct++; // class 0 iff h < 0.5
		}
		System.out.printf("correct rate = %4.2f\n", ((double)correct / (classA.templates.size() - TRAINING_COUNT)));

		// these should all belong to class 1
		correct = 0;
		System.out.println(classB.name + ":");
		for (int i = TRAINING_COUNT; i < classB.templates.size(); i++) {
			double[] xs = toXs(classB.templates.get(i));
			double h = h(xs, w);
			System.out.printf("%4.2f\n", h);
			if (h >= 0.5) correct++; // class 0 iff h >= 0.5
		}
		System.out.printf("correct rate = %4.2f\n", ((double)correct / (classB.templates.size() - TRAINING_COUNT)));
	}
	
	/**
	 * Convert template points (Point3D) to an array of doubles. 
	 * @param t
	 * @return
	 */
	public double[] toXs(Template t) {
		double[] xs = new double[N];
		xs[0] = 1.0;
		int k = 1;
		for (int j = 0; j < GestureClass.SAMPLE_POINTS_COUNT; j++) {
			Point3D p = t.get(j);
			xs[k++] = p.x;
			xs[k++] = p.y;
			xs[k++] = p.z;
		}
		return xs;
	}


	/**
	 * Generate training data in a matrix format given a vector of templates.
	 * Each row xs[i] contains one feature vector (N dimensional).
	 * ys[i] is the class (0 or 1) of this feature vector.
	 * The pair xs[i], ys[i]) is one training example (associates feature vector and class).
	 * 
	 * @param gesture training data is chosen from these gesture's templates (input)
	 * @param startIndexTemplates index of first template to use as training data
	 * @param count number of templates to use as training data
	 * @param xs feature vector in matrix format (output, array must exist)
	 * @param ys class vector in matrix format (output, array must exist)
	 * @param startIndexXs index of first row of matrix to store feature vectors
	 */
	public void getTrainingData(GestureClass gesture, int startIndexTemplates, int count, double[][] xs, int[] ys, int startIndexXs) {
		for (int i = 0; i < count; i++) {
			xs[i + startIndexXs][0] = 1.0;
			int k = 1;
			Template t = gesture.templates.get(i + startIndexTemplates);
			for (int j = 0; j < GestureClass.SAMPLE_POINTS_COUNT; j++) {
				Point3D p = t.get(j);
				xs[i + startIndexXs][k++] = p.x;
				xs[i + startIndexXs][k++] = p.y;
				xs[i + startIndexXs][k++] = p.z;
			}
			ys[i + startIndexXs] = gesture.gestureId;
		}
	}

	
	/**
	 * Compute vector of weights given a bunch of training examples (feature vector, class)
	 * @param trainXs feature vectors for training
	 * @param trainYs classes of these feature vectors
	 * @return vector of weights
	 */
	public double[] train(double[][] trainXs, int[] trainYs) {
		// TODO: implement
		return new double[] {0.0, 0.0};
	}


	/**
	 * Scalar product of a and b.
	 * @param a
	 * @param b
	 * @return scalar product of a and b
	 */
	public double dot(double[] a, double[] b) {
		double dot = 0;
		int n = a.length;
		for (int i = 0; i < n; i++) {
			dot += a[i] * b[i];
		}
		return dot;
	}

	
	/**
	 * The logistic function (sigmoid function).
	 * @param x
	 * @param w
	 * @return
	 */
	public double h(double[] x, double[] w) {
		// TODO: implement
		return 0.0;
	}


	/**
	 * The cost function for a single point.
	 * @param hx output of logistic function
	 * @param y classes (0 or 1)
	 * @return
	 */
	public double cost(double hx, int y) {
		// TODO: implement
		return 0.0;
	}


	/**
	 * The total cost across training samples.
	 * @param hx output of logistic function
	 * @param y classes (0 or 1)
	 * @return
	 */
	public double J(double[] hx, int[] y) {
		// TODO: implement
		return 0.0;
	}

	
	/**
	 * Gradient of cost function across training set.
	 * The gradient contains the direction and magnitude of the largest positive slope.
	 * @param x feature vectors (one per row)
	 * @param hx outputs of logistic function
	 * @param y classes (0 or 1)
	 * @return the gradient
	 */
	public double[] gradJ(double[][] x, double [] hx, int[] y) {
		int M = x.length;
		int N = x[0].length;
		double[] gradJ = new double[N];
		for (int j = 0; j < N; j++) {
			for (int i = 0; i < M; i++) {
				gradJ[j] += (hx[i] - y[i]) * x[i][j];
			}
			gradJ[j] = gradJ[j] / M;
		}
		return gradJ;
	}

	
	/**
	 * Start it up.
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		GestureClass leftRight = new GestureClass(basePath + "left-right.txt", "Left Right", 0);
		GestureClass circles = new GestureClass(basePath + "circle.txt", "Circles", 1);
		GestureClass leftRightArc = new GestureClass(basePath + "left-right-arc.txt", "Left Right Arc", 2);
		GestureClass infinity = new GestureClass(basePath + "infinity.txt", "Infinity", 3);
		
		leftRight.resample();
		circles.resample();
		leftRightArc.resample();
		infinity.resample();
		
		LogisticRegression lr = new LogisticRegression();
		
		lr.trainAndCrossValidate(leftRight, circles);
		lr.trainAndCrossValidate(leftRight, leftRightArc);
		lr.trainAndCrossValidate(leftRight, infinity);
		
		lr.trainAndCrossValidate(circles, leftRightArc);
		lr.trainAndCrossValidate(circles, infinity);
		
		lr.trainAndCrossValidate(leftRightArc, infinity);
	}

}
