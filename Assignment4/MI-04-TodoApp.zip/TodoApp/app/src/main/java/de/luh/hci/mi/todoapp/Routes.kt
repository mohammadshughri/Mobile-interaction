package de.luh.hci.mi.todoapp

// Each navigation destination (screen) has a "route" associated to it.
object Routes {
    const val TODO_LIST = "todo_list"
    const val ADD_EDIT_TODO = "add_edit_todo"
}