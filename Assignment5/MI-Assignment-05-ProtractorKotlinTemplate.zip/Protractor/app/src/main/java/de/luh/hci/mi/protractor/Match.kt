package de.luh.hci.mi.protractor

data class Match(val score: Float, val theta: Float) {
	var template: Template? = null
}